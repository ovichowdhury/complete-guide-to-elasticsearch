(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.photo = function() {
	this.initialize(img.photo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,672,560);


(lib.dot = function() {
	this.initialize(img.dot);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1,1);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ARxCuQgrguAAhLQAAhIArgwQAugwBHAAQBNAAAqA2QAmAzAABOIAAAGIj2AAQAEAoAXAXQAZAWAlAAQA7AAAXgtIBEAOQgQAqgoAZQgqAZg0AAQhJAAgsgugASPAUICpAAQgDghgUgUQgXgXgkAAQhNAAgKBMgAkcCuQgrguAAhLQAAhIArgwQAugwBHAAQBNAAAqA2QAmAzAABOIAAAGIj2AAQAEAoAXAXQAZAWAlAAQA7AAAXgtIBEAOQgQAqgoAZQgqAZg0AAQhJAAgsgugAj+AUICpAAQgFghgUgUQgVgXgkAAQhNAAgKBMgAypDBQgfgbAAgsQAAguAigXQAbgVA8gKIA9gLQAbgEAAgUQAAgrg9AAQg8AAgHA2IhGgGQAEgwAlgeQAmgdA6AAQCEAAAAB6IAAC4IACAVIg/AAIAAgiIgCAAQgfAqhDAAQg2AAgigbgAxPBOQguALAAAfQAAAsA2AAQBSAAAAhQIAAgIIACgOgA4DB4IBFgGQARAyA4AAQAZAAARgLQAQgMAAgRQAAgPgQgKQgJgEghgLIghgIQgwgMgXgTQgbgXAAgnQAAgsAjgZQAkgbA4AAQA0AAAkAZQAjAXAGAsIhDAGQgMgpg0AAQg0AAAAAjQAAAYA0ANIAjAIQA0AMAXAVQAZAVAAAoQAAAugjAdQgkAbg6AAQh7AAgThkgAW5DUIAAhLIBLAAIAABLgAPCDUIAAipQAAhfg+AAQhFAAAABbIAACtIhHAAIAAirQAAhdg+AAQhFAAAABbIAACtIhHAAIAAk8IBFAAIgCApIACAAQAZgyBEAAQBBAAAdA3QAkg3BHAAQBwAAAACBIAADEgAGUDUIAAk8IBGAAIAAE8gAEvDUQg0AAgVgRQgUgRAAgsIAAi4IgwAAIAAg2IAwAAIAAhUIBJAAIAABUIA6AAIAAA2Ig6AAIAACVQAAAjAIALQAGAIAZAAIAXAAIgKA7gAnNDUIAAipQAAhfg8AAQhFAAAABbIAACtIhJAAIAAirQAAhdg8AAQhFAAAABbIAACtIhHAAIgCk8IBFAAIAAApQAZgyBEAAQBFAAAZA3QAog3BDAAQByAAAACBIAADEgAGRiSIAAhJIBMAAIAABJg");
	this.shape.setTransform(153.975,21.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(0,0,308,44), null);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ACDD7QgUgLgNgSQgMgXAAgdQAAgZAMgoQAJgbAWgrQAZgmAXgYQAdgeAfgPQAggQAmAAQAbAAAOALQANAMAAAWQAAAbgNATQgOAXgZASIg2AiIg6AWIgeALQgGAbAAAeQAAAkANANQALAOAVAAQAZAAAWgOQAdgNAXgiIALAFQgLAUgXAWQgWAXgZAJQgbANgdAAQgZAAgXgLgAEEg/IgkAoIggA4QgSAmgEAbIAAACIAmgQIAtgbQAWgRAOgeQAQgXAAglIgFgWQAAgFgGAAQgQAAgSAOgAipDuQgZgZAAgwQAAgkAJgdQAQgyALgUQASghAXgbQAbgbAfgPQAdgQAoAAQAdAAAUAOQAXAPAAAbQAAAOgHANQgGAPgMAHQgLAJgQAAQgPAAgHgJQgHgHAAgNQAAgWAQgNQANgQAWgFIgPgNIgZgFQgXAAgZAUQgXAVgUAkQgQAXgQA3QgLAxAAArQAAAiANANQAQAQASAAQAXAAAWgOQAVgLAagmIANAFQgLAUgWAWQgWAXgXAJQgbANgdAAQgkAAgdgYgAlpECQgNgJgCgHQgMgLAEgUQAIggAEgLIBBjMIgCgVQAAgIgQAAQgLAAgVAPQgPAOgSAbQgQAWgUAlIg4CTIgQA4IhGAAIBUkoIAAgOQgDgGgLAAQgLAAgMANQgJAKgQAlIgIAdIgOAAIASgxQAOgmAUgNQAYgOAVAAQAXAAAIAHQAHAHAFAPQACAOgCAPIgbB1QANgiAQggQAXgpARgXQAdgdAPgHQAUgJAbAAQAdAAANAOQAMAPAAAVIgKAuIg+C9QgHAWACAHQAAAJANAAQAMAAALgLQAOgSALgfIAJgbIAOAAIgTAvQgEAUgSAXQgQAPgOADQgNAGgQAAgAs3D7QgUgLgNgSQgLgXAAgdQAAgZALgoQAJgbAWgrQASgdAeghQAdgeAfgPQAggQAnAAQAbAAANALQAQAMAAAWQAAAZgQAVQgNAXgZASIg2AiIg7AWIgdALQgHAbAAAeQAAAkAOANQAKAOAVAAQAZAAAWgOQAegNAWgiIALAFQgLAUgWAWQgXAXgZAJQgbANgdAAQgZAAgXgLgAq2g/QgXAXgLARQgOAQgUAoQgRAmgFAbIAAACIAmgQIAtgbQAXgRANgeQAQgXAAglIgFgWQAAgFgGAAQgQAAgSAOgAwRD5QgLgJAAgZQAAgSALgdIBEjBQALgmgUAAQgOAAgLAQQgLALgLAhIgMAdIgLAAIAQgxQALgdALgLQAMgLARgKQAMgEAUAAQAUAAAOAHQALALACALIAAAdIhMDjQgHAWACAHQACAJAMAAQANAAAJgNQALgLAOgkIALgbIALAAIgPAvQgJAYgQAQIgbAVIgfAGQgbAAgMgNgAzZDlIgCgbIAPg9QgLAbgLASQgXAmgbAUQgZASgfAAQgVAAgPgJQgOgJgLgUQgJgSAAgfQAAglAJgdQAFgSAZg2QAbgsARgSQAeggAdgPQAggQAmAAQASAAALAJQAHAHAEALIAeh1QAHgXgHgLQgKgJgfAAIAEgNQAeAAApgJQAXgGASgGIAPgGIh/HKQgEALAAAQQAEALAMAAQAJAAANgNQAHgLAQgkIAJgbIALAAIgQAvQgHAbgNANQgOASgPADQgOAGgPAAQgnAAgEghgAzng7QgUATgSAbQgJANgZAuQgNAigHAkQgJAiAAAkQAAAZAHANQAGAOAOAAQALAAAXgTQAUgUASgbIAkhKQAJgSAHgUIAbhpQgDgMgIgIQgJgJgMAAQgSAAgbAPgA4vECIgOgOQgHgPACgOIAHgrIAZhYIgZA5QgSAmgYAiQgTAZgYANQgcALgRAAQgeAAgNgNQgOgJAAgZQAAgZAKgbIA+i8QAFgNAAgQQgFgJgLAAQgJAAgLANQgJAHgQAoIgLAaIgMAAIARguQAKgdAOgLQANgOARgHQAIgEATAAQAfAAAJALQALAQgCAVQAAAWgJAYIg9C2QgSAyAdAAQAQAAAQgQQANgLAXgeIBDiSIAeheIgDAQIAKgkIBFgJIhREdIgEAbQAAALANAAQAQAAAJgNQAOgSAIgdIAKgbIANAAIgQAvQgLAdgNALQgOASgNADQgQAGgQAAgA+zD0QgLgNAEgXIAShIQgNAggQAYQgUAngbAPQgbAQgUAAQgiAAgQgWQgQgSAAgmQAAgnAMgfQALgpASghQANgeAdgjQAigiAVgNQAYgQAgAAQAZAAAJAUQAHAJACAQIAJgkIBIgJIhYEtIACAQQAAAGAMAAQANAAAJgNQAJgJAQgmIAJgbIALAAIgQAvQgLAdgLALIgbAVQgOAGgNAAQgeAAgLgSgA/Ag5QgSAOgQAeQgUAggLAdIgXBGIgHBIQAAAXAFANQAGAMAJAAQAOAAASgTQAUgUAQgYIAihGQAEgJAXhGIAAgFIALgnQAAgUgHgQQgHgSgUAAQgPAAgQAPgAdVDPQgsguAAhLQAAhJAsgvQAugwBHAAQBNAAApA3QAmAxAABPIAAAGIj2AAQAEAoAXAXQAZAXAmAAQA6AAAXguIBFAOQgRAqgoAZQgpAZg0AAQhJAAgsgugAdyA1ICpAAQgEgigVgTQgVgXgjAAQhOAAgKBMgAJZDiIgIgIQgXgZAAgmQAAgnAXgWIAKgIQAbgVA8gKIA9gLQAbgEAAgVQAAgqg8AAQg7AAgKA1IhFgGQACgYALgUQALgTASgOQAlgdA7AAQCDAAAAB6IAAC4IACAVIg/AAIAAgiIgCAAQgfAqhDAAQg2AAghgbgAKyBvQgtALAAAfQAAAsA2AAQBRAAAAhQIAAgIIACgOgAamD1IAAijQAAhlhDAAQhHAAAABfIAACpIhJAAIAAmvIBJAAIgCCYQAfguBBAAQA2AAAdAiQAgAjAAA6IAADGgAVvD1Qg0AAgTgRQgVgPAAguIAAi4IgwAAIAAg2IAwAAIAAhUIBHAAIAABUIA9AAIAAA2Ig9AAIAACVQAAAjAIALQAHAIAbAAIAVAAIgJA7gAQPD1Qg0AAgVgRQgVgRAAgsIAAi4IguAAIAAg2IAuAAIAAhUIBJAAIAABUIA6AAIAAA2Ig6AAIAACVQAAAjAIALQAGAIAZAAIAXAAIgIA7gAuwilQgLgPACgOQACgWAQgMQASgNASAAQASAAALALQAMAQgDANQgCATgQAPQgPAOgVAAQgSAAgLgMg");
	this.shape.setTransform(210.675,19.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-4.3,-6.9,430,52.4), null);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ACzEOIgKg7IAlAAQATAAALgKQAIgIAKgbIAFgLIh5k2IBPAAIBNDpIBNjpIBNAAIiHFoQgRAmgVAOQgXANguAAgAIBB8QgsguAAhLQAAhKAuguQAsgwBLAAQBJAAAuAwQAsAuAABKQAABLgsAuQguAwhLAAQhJAAgugwgAI1hJQgXAdAAAvQAAAwAXAdQAZAeAqAAQAqAAAZgeQAWgdAAgwQAAgvgWgdQgZgggqABQgqgBgZAggANZAlIAAjAIBJAAIAACsQAABdBBAAQBHAAAAhiIAAinIBGAAIAAE8IhCAAIAAgrIgCAAQggA0hAAAQhzAAAAiFgAwBAlIAAjAIBJAAIAACsQAABdBBAAQBHAAAAhiIAAinIBHAAIAAE8IhDAAIAAgrIgCAAQgfA0hBAAQhzAAAAiFgAlKB6QgqguAAhJQAAhIAnguQAqgwBDAAQBJAAAfAyIgCicIBJAAIAAGuIhFAAIACgrIgCAAQgfAxhNAAQhBAAgngtgAkShHQgXAdAAAtQAAAwAXAdQAZAeAnAAQAqAAAZgeQAZgdAAgwQAAgtgZgfQgZgdgqgBQgnABgZAfgA08B2IAAArIhCAAIAAmuIBHAAIAACcQAjgyBDAAQBCAAAqAwQAoAuAABIQAABJgoAuQgqAthAAAQhJAAgkgxgA0ghJQgZAdAAAvQAAAwAWAdQAZAeAqAAQAoAAAZgeQAXgdAAgwQAAgtgXgdQgZgfgogBQgnABgZAdgATEChIgCk8IBFAAIAAAuQAUg0BFAAIAVAAIAKBDIgnAAQgoAAgOARQgXAUAABHIAACTgAn8ChIAAmuIBJAAIAAGugAqWChIAAk8IBHAAIAAE8gAqYjEIAAhJIBLAAIAABJg");
	this.shape.setTransform(140.725,27);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(0,0,281.5,54), null);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ATZDHQgfgbAAgrQAAguAhgXQAcgVA8gLIA9gKQAbgEAAgUQAAgsg9AAQg+AAgHA1IhHgFQAHgwAlgdQAmgdA6AAQCEAAAAB6IAADMIg/AAIAAgOIACgTIgCAAQgfAqhDAAQg4AAgggcgAUzBVQgwAKAAAfQAAAsA4AAQAmAAAVgVQAXgUAAgmIAAgIIACgPgA8aC1QgsguAAhLQAAhIAsgwQAugwBHAAQBNAAAqA2QAlAyAABOIAAAHIj0AAQAFAnAWAXQAXAXAoAAQA4AAAXguIBFAPQgRApgnAaQgqAZg0AAQhJAAgsgugA79AaICpAAQgCgggVgVQgXgXgjAAQhLAAgNBMgEgi5ABlIBJgGQANBFBRAAQBRAAAAhBQAAgbgUgOQgPgLgsgKIghgLQh7ggAAhcQAAg2ApghQAqgkBFAAQBDAAAnAgQAoAfAGA2IhJAEQgMg4hFAAQgfAAgVAOQgTARAAAXQAAAZAVAPQAOAKAsAPIAfAIQBDAVAZAWQAiAbAAA0QAAA9guAlQgsAkhJAAQiSAAgTh+gAegCzQgpguAAhJQAAhIAnguQAqgwBDAAQBJAAAfAyIgCicIBJAAIAAGuIhFAAIACgsIgCAAQgfAyhNAAQhBAAgogtgAfbgOQgXAcAAAuQAAAwAXAdQAXAdAnAAQAqAAAZgdQAZgdAAgwQAAgugZgeQgZgegqAAQgnAAgXAggANHDUQgPgPAAgTQgDgUAHgdIBEjrIg7AAIACgMIA9AAIAbhjQAZAAANgCIAggHIgeBsIBSAAIgDAMIhTAAIhNEIQgEAWAHAHQAJAKANAAQAMAAAPgMQAOgNANgkIAJgbIAOAAIgOAoQgNApgZARQgbARgbAAQgZAAgSgMgAKDDbQgNgJgEgHQgHgLACgUQAAgMAJgfIA8i1IAFgXQAFgJgFgMQgFgIgKAAQgMAAgUAPQgOAMgWAdIgkA8QgXAxgJAeQgNAdgHAbIgSBDIhGAAIBUkoIgDgOQgCgGgJAAQgNAAgMANQgHAMgPAjIgJAeIgOAAIAQgyQAQgmAUgNQAUgOAZAAQAWAAAHAHQAMALACALIAAAdIgZBuQALgdAOgaQAZgwASgUQAWgYAUgMQATgJAbAAQAfAAANAOQAMAPgCAVQAAAZgHAWIhAC8QgGAWACAHQAAAKAOAAQAHAAAPgMQAOgSALgfIAJgbIALAAIgQAvQgEAUgSAXQgQAPgNADQgOAHgQAAgAC2DUQgUgJgOgUQgLgXAAgdQAAgZALgoQAJgbAXgqQANgdAfgiQAegeAfgPQAggQAoAAQAbAAAMALQAPAKAAAYQAAAbgNAUQgOAZgbAPIg0AiIhXAhQgHAbAAAeQAAAiALAPQAOAOAUAAQAZAAAWgOQAXgLAdgkIALAFQgLAUgXAWQgdAZgSAHQgbAOgdAAQgZAAgWgMgAE2hmQgdAdgHALIgfA5QgTAlgEAbIAkgOQAZgLAUgQQAZgVANgZQAOgbAAgiIgCgWIgHgFQgQAAgSAOgAgxDUQgQgPgCgTQAAgfAHgSIBCjrIg6AAIADgMIA8AAIAbhjQAYAAAMgCIAhgHIgdBsIBRAAIgCAMIhTAAIhMEIQgGAUAIAJQAGAKAOAAQANAAAQgMQANgNAOgkIAJgbIAOAAIgOAoQgNApgZARQgbARgaAAQgbAAgQgMgAj1DbQgLgFgHgLQgHgLACgUQAAgMAKgfIA8i1IAFgXQAEgJgEgMQgFgIgLAAQgLAAgVAPQgNAMgXAdIgjA8Ig9CiIgMAoIhDAAIBTkoIgCgOQgCgGgKAAQgNAAgLANQgHAMgQAjIgJAeIgNAAIAPgyQAQgmAVgNQAUgOAYAAQAVAAAJAHQALALADALIAAAdIgbByQAKgfARgcQAYgwASgUQAZgbASgJQASgJAbAAQAiAAAJAOQAQAPgFAVQAAAbgJAUIg/C8IgEAdQACAKANAAQAHAAAQgMQANgSAMgfIAIgbIAMAAIgQAvQgLAbgMAQQgNANgQAFIgdAHgAr3DFQgbgXAAg2QAAgSAKgtQAGggATghQANgfAYgeQAXgYAfgSQAegQApAAQAsAAAZAZQAZAZAAA2QAAAegJAdQgHAngPAdQgRAigYAbQgWAZggARQgeARgoAAQgrAAgZgbgAp2hiQgQAQgSAeIgdBAIgSBKIgHBIQAAAbAHAOQALALANAAQAVAAAPgQQAQgOAVgfQAZg2ACgLQAJgZAIgyIAIhHQAAgdgIgLQgGgOgSAAQgSAAgSASgAwZDHQgZgZAAgwQAAgUAJgtQAMgmAPgfQASgkAZgZQAUgWAkgUQAggQAmAAQAgAAAUAOQAUARAAAZQAAAOgGANQgKATgJAEQgIAJgTAAQgNAAgJgJQgHgHAAgOQAAgWAQgNQASgTASgCIgQgNQgNgFgMAAQgWAAgZAUQgbAZgQAgQgWAkgJAqQgOAtAAAvQAAAiAOANQAQAQARAAQAZAAAXgOQAUgLAbgmIALAFQgIAUgXAWQgXAXgZAJQgWAOggAAQgmAAgdgZgAbzDaIAAigQAAhohCAAQgsAAgPAkQgMAaAAA6IAACQIhJAAIAAk8IBFAAIAAAqQAfgyBDAAQA2AAAdAhQAfAkAAA7IAADEgA0wDaIAAmuIBJAAIAAGugA3KDaIAAmuIBHAAIAAGug");
	this.shape.setTransform(221.375,18.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-2,-4.5,446.8,45.4), null);


(lib.mc_photo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.photo();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_photo, new cjs.Rectangle(0,0,672,560), null);


(lib.mc_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AikD6IAAnzIFEAAIAABNIjuAAIAACDIDdAAIAABKIjdAAIAACMIDzAAIAABNg");
	this.shape.setTransform(334.8,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AhYDxQgvgVgfghQgigkgRguQgRgvAAg5QAAg4ARguQARgwAigjQAhgiAtgVQAwgUA3AAQBSAAA4AnQA4AmAXBAIhZARQgTgngggWQgigWgtABQgkAAgdAOQgdAOgUAZQgVAZgKAiQgLAiAAAmQAAAmAMAjQALAiAUAZQAVAZAdANQAdAOAlAAQAyAAAfgYQAggYASghIBYAOQgMAegTAZQgUAagbATQgcATgjAMQgjALguAAQg3AAgugTg");
	this.shape_1.setTransform(283.8,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEFEFE").s().p("ACeD6IgziPIjaAAIgzCPIhSAAIAAgYIC0nbICEAAICxHbIAAAYgAhUAhIClAAIhHjOIgVAAg");
	this.shape_2.setTransform(229.8,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEFEFE").s().p("Ai4D6IAAnzIC4AAQA0AAAjAMQAkAMAVAVQAWAUAJAdQAKAcAAAhQAAAngOAcQgNAdgZASQgZAUgjAJQgiAJgsAAIhaAAIAADAgAhfgQIBUAAQAWAAAVgEQATgDAPgKQAOgIAIgQQAIgOAAgXQAAgXgIgQQgIgPgOgJQgOgIgUgFQgSgDgXAAIhWAAg");
	this.shape_3.setTransform(184.8,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEFEFE").s().p("Ah+DkQg0gkgLhLIBUgHQAIAmAcAVQAdAWAtAAQAsAAAZgWQAZgUgBgkQAAgRgGgLQgHgMgMgIQgLgIgSgGIhLgWQgggKgcgNQgdgOgQgPQgTgSgJgYQgKgWAAgfQAAggAMgaQAOgdAWgRQAXgUAggLQAjgLAmAAQBOAAAsAlQAtAmAIA+IhTAHQgHgfgYgSQgWgSgpAAQgmAAgWASQgVATAAAcQAAAPAHAMQAFAKANAIQANAKAPAFQAQAHAWAGIAjAMQAiALAbAMQAaALATAQQATAQAJAWQALAXAAAhQAAAjgOAeQgOAegZAUQgaAVghALQgiALgrAAQhMAAgzglg");
	this.shape_4.setTransform(134.3,-0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEFEFE").s().p("AikD6IAAnzIFEAAIAABNIjuAAIAACDIDdAAIAABKIjdAAIAACMIDzAAIAABNg");
	this.shape_5.setTransform(87.8,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEFEFE").s().p("ABqD6IiYjEIg5AAIAADEIhWAAIAAnzICiAAQAkAAAkAFQAjAGAcATQA7AmAABPQAAAigLAZQgJAZgRASQgTATgUAJQgUALgZAGICQC1IAAAYgAhngUIBMAAQAxgBAegRQAdgUAAgpQgBgqgdgQQgdgQgxAAIhMAAg");
	this.shape_6.setTransform(41.3,0);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FEFEFE").s().p("ACeD6IgziPIjaAAIgzCPIhSAAIAAgYICznbICFAAICxHbIAAAYgAhUAhIClAAIhHjOIgVAAg");
	this.shape_7.setTransform(-13.2,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FEFEFE").s().p("AhUD5QgkgLgagaQgZgYgPgoQgNgoAAg3IAAk4IBXAAIAAE2QAABFAeAhQAdAjA1AAQA1AAAegjQAdghAAhFIAAk2IBYAAIAAE4QAAA2gOApQgOAogaAYQgZAagmALQgkALgvAAQgvAAglgLg");
	this.shape_8.setTransform(-66.7,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FEFEFE").s().p("ACeEYIgug6QgZAMgbAGQgbAGghABQg5AAgugUQgvgTgfgjQgggigTgyQgRguAAg6QAAg7ARgvQATgxAggiQAggkAvgTQAvgUA3AAQA4AAAuATQAuAUAhAjQAgAhASAzQATAxAAA5QAAA7gTAxQgUAwgjAjIBDBQIAAAYgAhDi9QgeAOgVAaQgTAXgMAjQgLAjAAAoQAAAoAMAiQALAiAUAZQATAZAfAPQAcAOAnAAQAlAAAdgNQAdgNAVgZQAVgbALghQALgjAAgoQAAgogLgkQgLghgVgaQgVgYgdgPQgdgOgmABQgmgBgcAOg");
	this.shape_9.setTransform(-125.7,2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FEFEFE").s().p("Ah+DkQg0gkgLhLIBUgHQAIAmAcAVQAdAWAtAAQAsAAAZgWQAZgUgBgkQAAgRgGgLQgHgMgMgIQgKgIgTgGIhLgWQgggKgcgNQgcgNgRgQQgTgTgJgXQgKgWAAgfQAAggAMgaQAOgdAWgRQAXgUAggLQAjgLAmAAQBOAAAsAlQAtAmAJA+IhUAHQgHgfgYgSQgWgSgpAAQgmAAgWASQgVATAAAcQAAAPAHAMQAFAKANAIQANAKAPAFQAQAHAWAGIAjAMQAiALAbAMQAaALATAQQATAQAJAWQALAXAAAhQAAAjgOAeQgOAegZAUQgaAVghALQgiALgrAAQhMAAgzglg");
	this.shape_10.setTransform(-180.7,-0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FEFEFE").s().p("AkND4QgqgSggghIgfgfIA9g+IAfAfQApAqA8AAQA7AAApgqIGKmPIA+A/ImKGOQggAhgqASQgrARgtAAQguAAgqgRg");
	this.shape_11.setTransform(-285.2,23.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FEFEFE").s().p("AhME0IFWlXQAqgqAAg8QAAg7gqgrQgqgqg7AAQg8AAgpAqImMGOIg+g9IGMmPQAgghArgRQAqgRAugBQAuAAAqASQAqARAhAhQBDBEAABgQAABghDBDIlWFYg");
	this.shape_12.setTransform(-267.225,14);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FEFEFE").s().p("Aj8FhQgrgSggghQhDhEAAhgQAAhfBDhDIFWlZIA9A+IlVFYQgqAqAAA7QAAA8AqAqQAqAqA7ABQA8AAApgrIGMmOIA+A+ImMGOQggAhgrASQgqARguAAQguAAgqgRg");
	this.shape_13.setTransform(-313.2,-14);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FEFEFE").s().p("Al2DLIGJmPQAhghAqgRQAqgRAugBQAuAAAqASQApARAhAhIAfAgIg+A+IgfggQgqgqg6AAQg8AAgpAqImKGPg");
	this.shape_14.setTransform(-295.2,-23.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_logo, new cjs.Rectangle(-352.7,-51,704,102), null);


(lib.mc_cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {off:0,on:1};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AFWAYQgJgJAAgPQAAgOAJgJQAJgKAOAAQAPAAAJAKQAJAJAAAOQAAAPgJAJQgJAKgPgBQgOABgJgKgAFegQQgFAGgBAKQABALAFAGQAGAHAJAAQAKAAAFgGQAGgIAAgKQAAgKgGgGQgGgHgJAAQgJAAgGAHgAETAYQgIgJAAgPQAAgOAIgJQAJgKAPAAQAVABAHARIgLACQgGgKgLAAQgJAAgGAHQgGAGABAKQgBALAGAGQAGAHAJAAQAMAAAFgLIALACQgHATgVgBQgPABgJgKgAB9AIIAAgoIALAAIAAAnQgBARAPAAQAPAAAAgRIAAgnIALAAIAAAoQAAAZgaAAQgZAAAAgZgAA6AYQgJgJAAgPQAAgOAJgJQAJgKAPAAQAOAAAJAKQAJAJAAAOQAAAPgJAJQgIAKgPgBQgQABgIgKgABCgQQgGAGAAAKQAAALAGAGQAGAHAKAAQAJAAAFgGQAGgIAAgKQAAgKgGgGQgFgHgJAAQgKAAgGAHgAhUAYQgJgJAAgPQAAgOAJgJQAIgKAQAAQAVABAHARIgLACQgFgKgMAAQgLAAgFAHQgGAGABAKQgBALAGAHQAFAGALAAQARAAACgQIgZAAIAAgJIAiAAIADADQAAAPgKAJQgIAHgNAAQgPAAgJgJgAmPAPIALgBQACALAMgBQAMAAAAgKQAAgGgMgDIgEgCQgTgDAAgOQAAgJAGgEQAHgGAKAAQAUAAADASIgLAAQgCgIgKAAQgLAAAAAIQAAAGAMAEIAFABQAJAEAEACQAGAEAAAHQAAAKgIAFQgGAGgLgBQgWAAgDgSgAq2APIALgBQACALAMgBQAMAAAAgKQAAgDgDgCIgJgEIgEgCQgUgDABgOQgBgJAHgEQAGgGAKAAQAVAAADASIgLAAQgDgIgKAAQgKAAAAAIQAAAGALAEIAGABQAKAEADACQAFAEAAAHQAAAKgHAFQgHAGgLgBQgVAAgDgSgAKaAgIAAg2IgTAAIAAgKIAwAAIAAAKIgSAAIAAA2gAJvAgIgcgxIAAAxIgLAAIAAhAIAOAAIAcAyIABAAIgBgyIAMAAIAABAgAISAgIAAhAIApAAIAAAKIgeAAIAAARIAcAAIAAAJIgcAAIAAASIAfAAIAAAKgAHqAgIAAg2IgSAAIAAgKIAwAAIAAAKIgSAAIAAA2gAHBAgIgegxIABAxIgLAAIAAhAIAOAAIAdAyIAAAAIAAgyIAKAAIAABAgADkAgIgTgZIgIAAIAAAZIgKAAIAAhAIAUAAQAMAAAGAFQAHAFABAJQAAAPgQAEIASAXIAAADgADJgCIAKAAQAOABABgLQgBgKgOAAIgKAAgAAOAgIAAgXIgUgkIAAgFIAKAAIAHAOIAJARIAQgfIALAAIAAAFIgVAkIAAAXgAh2AgIgdgxIgBAAIABAxIgLAAIAAhAIAOAAIAdAyIAAAAIAAgyIALAAIAABAgAi4AgIAAhAIALAAIAABAgAjqAgIAAhAIALAAIAAA2IAdAAIAAAKgAkcAgIAAhAIAKAAIAAA2IAeAAIAAAKgAlTAgIAAhAIAqAAIAAAKIgfAAIAAARIAdAAIAAAJIgdAAIAAASIAgAAIAAAKgAnEAgIAAg2IgTAAIAAgKIAxAAIAAAKIgSAAIAAA2gAnlAgIgUgZIgHAAIAAAZIgLAAIAAhAIAVAAQAMAAAFAFQAIAEAAAKQAAAPgQAEIATAXIAAADgAoAgCIAKAAQANABAAgLQAAgKgNAAIgKAAgAogAgIgGgSIgcAAIgGASIgLAAIAAgDIAXg9IARAAIAXA9IAAADgAopAEIgJgaIgDAAIgJAaIAVAAgApuAgIAAg2IgTAAIAAgKIAxAAIAAAKIgTAAIAAA2g");
	this.shape.setTransform(-1,0.7,2,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ARLEsMgtcAAAIAApXMA4jAAAIAAJXg");
	this.shape_1.setTransform(0,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.8)").s().p("ARLEsMgtcAAAIAApXMA4jAAAIAAJXg");
	this.shape_2.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-181,-30,362,60.1);


(lib.mc_back = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Egu3AnEMAAAhOHMBdvAAAMAAABOHg");
	this.shape.setTransform(335.9985,279.9988,1.12,1.12);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_back, new cjs.Rectangle(0,0,672,560), null);


(lib.clickthrough = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ARxCuQgrguAAhLQAAhIArgwQAugwBHAAQBNAAAqA2QAmAzAABOIAAAGIj2AAQAEAoAXAXQAZAWAlAAQA7AAAXgtIBEAOQgQAqgoAZQgqAZg0AAQhJAAgsgugASPAUICpAAQgDghgUgUQgXgXgkAAQhNAAgKBMgAkcCuQgrguAAhLQAAhIArgwQAugwBHAAQBNAAAqA2QAmAzAABOIAAAGIj2AAQAEAoAXAXQAZAWAlAAQA7AAAXgtIBEAOQgQAqgoAZQgqAZg0AAQhJAAgsgugAj+AUICpAAQgFghgUgUQgVgXgkAAQhNAAgKBMgAypDBQgfgbAAgsQAAguAigXQAbgVA8gKIA9gLQAbgEAAgUQAAgrg9AAQg8AAgHA2IhGgGQAEgwAlgeQAmgdA6AAQCEAAAAB6IAAC4IACAVIg/AAIAAgiIgCAAQgfAqhDAAQg2AAgigbgAxPBOQguALAAAfQAAAsA2AAQBSAAAAhQIAAgIIACgOgA4DB4IBFgGQARAyA4AAQAZAAARgLQAQgMAAgRQAAgPgQgKQgJgEghgLIghgIQgwgMgXgTQgbgXAAgnQAAgsAjgZQAkgbA4AAQA0AAAkAZQAjAXAGAsIhDAGQgMgpg0AAQg0AAAAAjQAAAYA0ANIAjAIQA0AMAXAVQAZAVAAAoQAAAugjAdQgkAbg6AAQh7AAgThkgAW5DUIAAhLIBLAAIAABLgAPCDUIAAipQAAhfg+AAQhFAAAABbIAACtIhHAAIAAirQAAhdg+AAQhFAAAABbIAACtIhHAAIAAk8IBFAAIgCApIACAAQAZgyBEAAQBBAAAdA3QAkg3BHAAQBwAAAACBIAADEgAGUDUIAAk8IBGAAIAAE8gAEvDUQg0AAgVgRQgUgRAAgsIAAi4IgwAAIAAg2IAwAAIAAhUIBJAAIAABUIA6AAIAAA2Ig6AAIAACVQAAAjAIALQAGAIAZAAIAXAAIgKA7gAnNDUIAAipQAAhfg8AAQhFAAAABbIAACtIhJAAIAAirQAAhdg8AAQhFAAAABbIAACtIhHAAIgCk8IBFAAIAAApQAZgyBEAAQBFAAAZA3QAog3BDAAQByAAAACBIAADEgAGRiSIAAhJIBMAAIAABJg");
	this.shape.setTransform(160.975,16.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Symbol8();
	this.instance.setTransform(161,16.9,1,1,0,0,0,154,21.9);
	this.instance.alpha = 0.3008;
	this.instance.filters = [new cjs.BlurFilter(10, 10, 1)];
	this.instance.cache(-2,-2,312,48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(2,-10,321,57), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACDD7QgUgLgNgSQgMgXAAgdQAAgZAMgoQAJgbAWgrQAZgmAXgYQAdgeAfgPQAggQAmAAQAbAAAOALQANAMAAAWQAAAbgNATQgOAXgZASIg2AiIg6AWIgeALQgGAbAAAeQAAAkANANQALAOAVAAQAZAAAWgOQAdgNAXgiIALAFQgLAUgXAWQgWAXgZAJQgbANgdAAQgZAAgXgLgAEEg/IgkAoIggA4QgSAmgEAbIAAACIAmgQIAtgbQAWgRAOgeQAQgXAAglIgFgWQAAgFgGAAQgQAAgSAOgAipDuQgZgZAAgwQAAgkAJgdQAQgyALgUQASghAXgbQAbgbAfgPQAdgQAoAAQAdAAAUAOQAXAPAAAbQAAAOgHANQgGAPgMAHQgLAJgQAAQgPAAgHgJQgHgHAAgNQAAgWAQgNQANgQAWgFIgPgNIgZgFQgXAAgZAUQgXAVgUAkQgQAXgQA3QgLAxAAArQAAAiANANQAQAQASAAQAXAAAWgOQAVgLAagmIANAFQgLAUgWAWQgWAXgXAJQgbANgdAAQgkAAgdgYgAlpECQgNgJgCgHQgMgLAEgUQAIggAEgLIBBjMIgCgVQAAgIgQAAQgLAAgVAPQgPAOgSAbQgQAWgUAlIg4CTIgQA4IhGAAIBUkoIAAgOQgDgGgLAAQgLAAgMANQgJAKgQAlIgIAdIgOAAIASgxQAOgmAUgNQAYgOAVAAQAXAAAIAHQAHAHAFAPQACAOgCAPIgbB1QANgiAQggQAXgpARgXQAdgdAPgHQAUgJAbAAQAdAAANAOQAMAPAAAVIgKAuIg+C9QgHAWACAHQAAAJANAAQAMAAALgLQAOgSALgfIAJgbIAOAAIgTAvQgEAUgSAXQgQAPgOADQgNAGgQAAgAs3D7QgUgLgNgSQgLgXAAgdQAAgZALgoQAJgbAWgrQASgdAeghQAdgeAfgPQAggQAnAAQAbAAANALQAQAMAAAWQAAAZgQAVQgNAXgZASIg2AiIg7AWIgdALQgHAbAAAeQAAAkAOANQAKAOAVAAQAZAAAWgOQAegNAWgiIALAFQgLAUgWAWQgXAXgZAJQgbANgdAAQgZAAgXgLgAq2g/QgXAXgLARQgOAQgUAoQgRAmgFAbIAAACIAmgQIAtgbQAXgRANgeQAQgXAAglIgFgWQAAgFgGAAQgQAAgSAOgAwRD5QgLgJAAgZQAAgSALgdIBEjBQALgmgUAAQgOAAgLAQQgLALgLAhIgMAdIgLAAIAQgxQALgdALgLQAMgLARgKQAMgEAUAAQAUAAAOAHQALALACALIAAAdIhMDjQgHAWACAHQACAJAMAAQANAAAJgNQALgLAOgkIALgbIALAAIgPAvQgJAYgQAQIgbAVIgfAGQgbAAgMgNgAzZDlIgCgbIAPg9QgLAbgLASQgXAmgbAUQgZASgfAAQgVAAgPgJQgOgJgLgUQgJgSAAgfQAAglAJgdQAFgSAZg2QAbgsARgSQAeggAdgPQAggQAmAAQASAAALAJQAHAHAEALIAeh1QAHgXgHgLQgKgJgfAAIAEgNQAeAAApgJQAXgGASgGIAPgGIh/HKQgEALAAAQQAEALAMAAQAJAAANgNQAHgLAQgkIAJgbIALAAIgQAvQgHAbgNANQgOASgPADQgOAGgPAAQgnAAgEghgAzng7QgUATgSAbQgJANgZAuQgNAigHAkQgJAiAAAkQAAAZAHANQAGAOAOAAQALAAAXgTQAUgUASgbIAkhKQAJgSAHgUIAbhpQgDgMgIgIQgJgJgMAAQgSAAgbAPgA4vECIgOgOQgHgPACgOIAHgrIAZhYIgZA5QgSAmgYAiQgTAZgYANQgcALgRAAQgeAAgNgNQgOgJAAgZQAAgZAKgbIA+i8QAFgNAAgQQgFgJgLAAQgJAAgLANQgJAHgQAoIgLAaIgMAAIARguQAKgdAOgLQANgOARgHQAIgEATAAQAfAAAJALQALAQgCAVQAAAWgJAYIg9C2QgSAyAdAAQAQAAAQgQQANgLAXgeIBDiSIAeheIgDAQIAKgkIBFgJIhREdIgEAbQAAALANAAQAQAAAJgNQAOgSAIgdIAKgbIANAAIgQAvQgLAdgNALQgOASgNADQgQAGgQAAgA+zD0QgLgNAEgXIAShIQgNAggQAYQgUAngbAPQgbAQgUAAQgiAAgQgWQgQgSAAgmQAAgnAMgfQALgpASghQANgeAdgjQAigiAVgNQAYgQAgAAQAZAAAJAUQAHAJACAQIAJgkIBIgJIhYEtIACAQQAAAGAMAAQANAAAJgNQAJgJAQgmIAJgbIALAAIgQAvQgLAdgLALIgbAVQgOAGgNAAQgeAAgLgSgA/Ag5QgSAOgQAeQgUAggLAdIgXBGIgHBIQAAAXAFANQAGAMAJAAQAOAAASgTQAUgUAQgYIAihGQAEgJAXhGIAAgFIALgnQAAgUgHgQQgHgSgUAAQgPAAgQAPgAdVDPQgsguAAhLQAAhJAsgvQAugwBHAAQBNAAApA3QAmAxAABPIAAAGIj2AAQAEAoAXAXQAZAXAmAAQA6AAAXguIBFAOQgRAqgoAZQgpAZg0AAQhJAAgsgugAdyA1ICpAAQgEgigVgTQgVgXgjAAQhOAAgKBMgAJZDiIgIgIQgXgZAAgmQAAgnAXgWIAKgIQAbgVA8gKIA9gLQAbgEAAgVQAAgqg8AAQg7AAgKA1IhFgGQACgYALgUQALgTASgOQAlgdA7AAQCDAAAAB6IAAC4IACAVIg/AAIAAgiIgCAAQgfAqhDAAQg2AAghgbgAKyBvQgtALAAAfQAAAsA2AAQBRAAAAhQIAAgIIACgOgAamD1IAAijQAAhlhDAAQhHAAAABfIAACpIhJAAIAAmvIBJAAIgCCYQAfguBBAAQA2AAAdAiQAgAjAAA6IAADGgAVvD1Qg0AAgTgRQgVgPAAguIAAi4IgwAAIAAg2IAwAAIAAhUIBHAAIAABUIA9AAIAAA2Ig9AAIAACVQAAAjAIALQAHAIAbAAIAVAAIgJA7gAQPD1Qg0AAgVgRQgVgRAAgsIAAi4IguAAIAAg2IAuAAIAAhUIBJAAIAABUIA6AAIAAA2Ig6AAIAACVQAAAjAIALQAGAIAZAAIAXAAIgIA7gAuwilQgLgPACgOQACgWAQgMQASgNASAAQASAAALALQAMAQgDANQgCATgQAPQgPAOgVAAQgSAAgLgMg");
	this.shape.setTransform(210.675,19.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Symbol7();
	this.instance.setTransform(204.3,24.2,1,1,0,0,0,204.3,24.2);
	this.instance.alpha = 0.3008;
	this.instance.filters = [new cjs.BlurFilter(10, 10, 1)];
	this.instance.cache(-6,-9,434,56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-9.3,-11.9,443,65), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACzEOIgKg7IAlAAQATAAALgKQAIgIAKgbIAFgLIh5k2IBPAAIBNDpIBNjpIBNAAIiHFoQgRAmgVAOQgXANguAAgAIBB8QgsguAAhLQAAhKAuguQAsgwBLAAQBJAAAuAwQAsAuAABKQAABLgsAuQguAwhLAAQhJAAgugwgAI1hJQgXAdAAAvQAAAwAXAdQAZAeAqAAQAqAAAZgeQAWgdAAgwQAAgvgWgdQgZgggqABQgqgBgZAggANZAlIAAjAIBJAAIAACsQAABdBBAAQBHAAAAhiIAAinIBGAAIAAE8IhCAAIAAgrIgCAAQggA0hAAAQhzAAAAiFgAwBAlIAAjAIBJAAIAACsQAABdBBAAQBHAAAAhiIAAinIBHAAIAAE8IhDAAIAAgrIgCAAQgfA0hBAAQhzAAAAiFgAlKB6QgqguAAhJQAAhIAnguQAqgwBDAAQBJAAAfAyIgCicIBJAAIAAGuIhFAAIACgrIgCAAQgfAxhNAAQhBAAgngtgAkShHQgXAdAAAtQAAAwAXAdQAZAeAnAAQAqAAAZgeQAZgdAAgwQAAgtgZgfQgZgdgqgBQgnABgZAfgA08B2IAAArIhCAAIAAmuIBHAAIAACcQAjgyBDAAQBCAAAqAwQAoAuAABIQAABJgoAuQgqAthAAAQhJAAgkgxgA0ghJQgZAdAAAvQAAAwAWAdQAZAeAqAAQAoAAAZgeQAXgdAAgwQAAgtgXgdQgZgfgogBQgnABgZAdgATEChIgCk8IBFAAIAAAuQAUg0BFAAIAVAAIAKBDIgnAAQgoAAgOARQgXAUAABHIAACTgAn8ChIAAmuIBJAAIAAGugAqWChIAAk8IBHAAIAAE8gAqYjEIAAhJIBLAAIAABJg");
	this.shape.setTransform(146.725,22);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Symbol6();
	this.instance.setTransform(146.7,22,1,1,0,0,0,140.7,27);
	this.instance.alpha = 0.3008;
	this.instance.filters = [new cjs.BlurFilter(10, 10, 1)];
	this.instance.cache(-2,-2,286,58);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(1,-10,295,68), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ATZDHQgfgbAAgrQAAguAhgXQAcgVA8gLIA9gKQAbgEAAgUQAAgsg9AAQg+AAgHA1IhHgFQAHgwAlgdQAmgdA6AAQCEAAAAB6IAADMIg/AAIAAgOIACgTIgCAAQgfAqhDAAQg4AAgggcgAUzBVQgwAKAAAfQAAAsA4AAQAmAAAVgVQAXgUAAgmIAAgIIACgPgA8aC1QgsguAAhLQAAhIAsgwQAugwBHAAQBNAAAqA2QAlAyAABOIAAAHIj0AAQAFAnAWAXQAXAXAoAAQA4AAAXguIBFAPQgRApgnAaQgqAZg0AAQhJAAgsgugA79AaICpAAQgCgggVgVQgXgXgjAAQhLAAgNBMgEgi5ABlIBJgGQANBFBRAAQBRAAAAhBQAAgbgUgOQgPgLgsgKIghgLQh7ggAAhcQAAg2ApghQAqgkBFAAQBDAAAnAgQAoAfAGA2IhJAEQgMg4hFAAQgfAAgVAOQgTARAAAXQAAAZAVAPQAOAKAsAPIAfAIQBDAVAZAWQAiAbAAA0QAAA9guAlQgsAkhJAAQiSAAgTh+gAegCzQgpguAAhJQAAhIAnguQAqgwBDAAQBJAAAfAyIgCicIBJAAIAAGuIhFAAIACgsIgCAAQgfAyhNAAQhBAAgogtgAfbgOQgXAcAAAuQAAAwAXAdQAXAdAnAAQAqAAAZgdQAZgdAAgwQAAgugZgeQgZgegqAAQgnAAgXAggANHDUQgPgPAAgTQgDgUAHgdIBEjrIg7AAIACgMIA9AAIAbhjQAZAAANgCIAggHIgeBsIBSAAIgDAMIhTAAIhNEIQgEAWAHAHQAJAKANAAQAMAAAPgMQAOgNANgkIAJgbIAOAAIgOAoQgNApgZARQgbARgbAAQgZAAgSgMgAKDDbQgNgJgEgHQgHgLACgUQAAgMAJgfIA8i1IAFgXQAFgJgFgMQgFgIgKAAQgMAAgUAPQgOAMgWAdIgkA8QgXAxgJAeQgNAdgHAbIgSBDIhGAAIBUkoIgDgOQgCgGgJAAQgNAAgMANQgHAMgPAjIgJAeIgOAAIAQgyQAQgmAUgNQAUgOAZAAQAWAAAHAHQAMALACALIAAAdIgZBuQALgdAOgaQAZgwASgUQAWgYAUgMQATgJAbAAQAfAAANAOQAMAPgCAVQAAAZgHAWIhAC8QgGAWACAHQAAAKAOAAQAHAAAPgMQAOgSALgfIAJgbIALAAIgQAvQgEAUgSAXQgQAPgNADQgOAHgQAAgAC2DUQgUgJgOgUQgLgXAAgdQAAgZALgoQAJgbAXgqQANgdAfgiQAegeAfgPQAggQAoAAQAbAAAMALQAPAKAAAYQAAAbgNAUQgOAZgbAPIg0AiIhXAhQgHAbAAAeQAAAiALAPQAOAOAUAAQAZAAAWgOQAXgLAdgkIALAFQgLAUgXAWQgdAZgSAHQgbAOgdAAQgZAAgWgMgAE2hmQgdAdgHALIgfA5QgTAlgEAbIAkgOQAZgLAUgQQAZgVANgZQAOgbAAgiIgCgWIgHgFQgQAAgSAOgAgxDUQgQgPgCgTQAAgfAHgSIBCjrIg6AAIADgMIA8AAIAbhjQAYAAAMgCIAhgHIgdBsIBRAAIgCAMIhTAAIhMEIQgGAUAIAJQAGAKAOAAQANAAAQgMQANgNAOgkIAJgbIAOAAIgOAoQgNApgZARQgbARgaAAQgbAAgQgMgAj1DbQgLgFgHgLQgHgLACgUQAAgMAKgfIA8i1IAFgXQAEgJgEgMQgFgIgLAAQgLAAgVAPQgNAMgXAdIgjA8Ig9CiIgMAoIhDAAIBTkoIgCgOQgCgGgKAAQgNAAgLANQgHAMgQAjIgJAeIgNAAIAPgyQAQgmAVgNQAUgOAYAAQAVAAAJAHQALALADALIAAAdIgbByQAKgfARgcQAYgwASgUQAZgbASgJQASgJAbAAQAiAAAJAOQAQAPgFAVQAAAbgJAUIg/C8IgEAdQACAKANAAQAHAAAQgMQANgSAMgfIAIgbIAMAAIgQAvQgLAbgMAQQgNANgQAFIgdAHgAr3DFQgbgXAAg2QAAgSAKgtQAGggATghQANgfAYgeQAXgYAfgSQAegQApAAQAsAAAZAZQAZAZAAA2QAAAegJAdQgHAngPAdQgRAigYAbQgWAZggARQgeARgoAAQgrAAgZgbgAp2hiQgQAQgSAeIgdBAIgSBKIgHBIQAAAbAHAOQALALANAAQAVAAAPgQQAQgOAVgfQAZg2ACgLQAJgZAIgyIAIhHQAAgdgIgLQgGgOgSAAQgSAAgSASgAwZDHQgZgZAAgwQAAgUAJgtQAMgmAPgfQASgkAZgZQAUgWAkgUQAggQAmAAQAgAAAUAOQAUARAAAZQAAAOgGANQgKATgJAEQgIAJgTAAQgNAAgJgJQgHgHAAgOQAAgWAQgNQASgTASgCIgQgNQgNgFgMAAQgWAAgZAUQgbAZgQAgQgWAkgJAqQgOAtAAAvQAAAiAOANQAQAQARAAQAZAAAXgOQAUgLAbgmIALAFQgIAUgXAWQgXAXgZAJQgWAOggAAQgmAAgdgZgAbzDaIAAigQAAhohCAAQgsAAgPAkQgMAaAAA6IAACQIhJAAIAAk8IBFAAIAAAqQAfgyBDAAQA2AAAdAhQAfAkAAA7IAADEgA0wDaIAAmuIBJAAIAAGugA3KDaIAAmuIBHAAIAAGug");
	this.shape.setTransform(221.375,18.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Symbol5();
	this.instance.setTransform(215.3,22.4,1,1,0,0,0,215.3,22.4);
	this.instance.alpha = 0.3008;
	this.instance.filters = [new cjs.BlurFilter(10, 10, 1)];
	this.instance.cache(-4,-6,451,49);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-7,-9.5,460,58), null);


(lib.mc_copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.c4 = new lib.Symbol4();
	this.c4.name = "c4";
	this.c4.setTransform(127.9,362,1,1,0,0,0,-46.1,12);

	this.c3 = new lib.Symbol3();
	this.c3.name = "c3";
	this.c3.setTransform(120.3,295.2,1,1,0,0,0,-3.7,11.2);

	this.c2 = new lib.Symbol2();
	this.c2.name = "c2";
	this.c2.setTransform(122.7,247,1,1,0,0,0,-69.3,17);

	this.c1 = new lib.Symbol1();
	this.c1.name = "c1";
	this.c1.setTransform(113.3,180.4,1,1,0,0,0,-0.7,12.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.c1},{t:this.c2},{t:this.c3},{t:this.c4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_copy, new cjs.Rectangle(107,158.5,460,238.5), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		/**
		* Squarewave CreateJS Template 3.3 (Feb '21)
		**/
		var root = r = this,
		    adCompleted = false,
			isOver = false,
			timeout,
			tl;
		
		var EO = Elastic.easeOut.config;
		var EI = Elastic.easeIn.config;
		var EIO = Elastic.easeInOut.config;
		var R = gsap.utils.Random;
		
		/**** uncomment to use within creative ******/
		/*
		root.clickthrough.on('mouseover' , onRollOver );
		root.clickthrough.on('mouseout' , onRollOut );
		root.clickthrough.on('click' , onClick );
		*/
		
		/*
		* remove elements for backup capture
		*/
		if( queryVar('capture') ) {
			// use this for removing items in backups
		}
		
		this.onInit = function()
		{
			setTimeout( function(){ 
				console.log('%c----------------------------------------\n------------- 15 SECONDS ---------------\n----------------------------------------\n', 'background: #ffff33; color: #ff00ff');
			} , 15000 );
				
			r.tl = tl = gsap.timeline({onComplete:function(){ if(!isOver){ r.adHelper.sleep(); } adCompleted = true; }});
			tl.add( "start" , "+=0" );
			tl.add( function(){ console.log('end'); } , "start+=14.5" );
			
			tl.addLabel("frame01", "start+=.25");
			tl.from(root.m_copy.c1, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01");
			tl.from(root.m_copy.c2, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.2");
			tl.from(root.m_copy.c3, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.4");
			tl.from(root.m_copy.c4, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.6");
			//tl.from(root.m_copy.c5, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.8");
			//tl.from(root.m_copy.c6, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=1");
			
			//tl.from(root.m_subTxt, .8, {alpha:0}, "frame01+=1");
		}
		
		this.onRollOverEvent = function(e)
		{
			// wake up creative if asleep //
			clearTimeout( timeout );
			if( root.adHelper && !root.adHelper.awake ) root.adHelper.wake();
			isOver = true;
			console.log("creative-mouse over" );
			if( adCompleted ) {}
			
			root.m_cta.gotoAndStop("on");
		}
		
		this.onRollOutEvent = function(e)
		{
			if( adCompleted ) timeout = setTimeout( function(){ if(!isOver) r.adHelper.sleep(); } , 3000 );
			isOver = false
			console.log("creative-mouse out" );
			if( adCompleted ) {}
			
			root.m_cta.gotoAndStop("off");
		}
		
		this.onClickEvent = function(e)
		{
			console.log("creative-click");
		}
		
		this.adHelper = null; // adhelper reference //
		this.onSlowDown = function()
		{
			console.log("creative-slowdown");
		}
		
		this.onSleep = function()
		{
			console.log("creative-sleep");
		}
		
		this.onWake = function()
		{
			console.log("creative-wake");
		}
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// pixel
	this.instance = new lib.dot();
	this.instance.setTransform(-10,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// clickthrough
	this.clickthrough = new lib.clickthrough();
	this.clickthrough.name = "clickthrough";
	this.clickthrough.setTransform(335.95,279.95,2.2399,2.2399,0,0,0,150,125);
	new cjs.ButtonHelper(this.clickthrough, 0, 1, 2, false, new lib.clickthrough(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickthrough).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Eg0fArwMAAAhXfMBo/AAAMAAABXfgEg0LArcMBoXAAAMAAAhW3MhoXAAAg");
	this.shape.setTransform(336,280);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// cta
	this.m_cta = new lib.mc_cta();
	this.m_cta.name = "m_cta";
	this.m_cta.setTransform(336,476);

	this.timeline.addTween(cjs.Tween.get(this.m_cta).wait(1));

	// logo
	this.instance_1 = new lib.mc_logo();
	this.instance_1.setTransform(336,78.1,0.5,0.5,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// copy
	this.m_copy = new lib.mc_copy();
	this.m_copy.name = "m_copy";

	this.timeline.addTween(cjs.Tween.get(this.m_copy).wait(1));

	// photo
	this.instance_2 = new lib.mc_photo();
	this.instance_2.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// back
	this.instance_3 = new lib.mc_back();
	this.instance_3.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(326,270,346,290);
// library properties:
lib.properties = {
	id: '297D501141974662AAF7687B5444E494',
	width: 672,
	height: 560,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/photo.jpg?1652983690124", id:"photo"},
		{src:"images/dot.png?1652983690124", id:"dot"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['297D501141974662AAF7687B5444E494'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;