(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.photo = function() {
	this.initialize(img.photo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);


(lib.dot = function() {
	this.initialize(img.dot);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1,1);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ab0DgIgKgwIAiAAQAYAAAPglIACgIIhkkDIBDAAIA/DCIACAAIA+jCIBCAAIhyEqQgMAhgTAKQgRALgnAAgAMHBnQgjglAAg/QAAg7AmgoQAlgoA6AAQBBABAhAtQAgAoAABBIAAAFIjMAAQAFBGBFAAQAvABAXgmIA3AKQgOAkghAVQghAXgtAAQg8AAgmgogAMggZICPAAQgHg/g/ABQg+gBgLA/gArnBnQgmgnAAg9QAAg7AmgoQAlgoA8AAQBBABAhAtQAgAoAABBIAAAFIjNAAQAHBGBEAAQAwABAUgmIA5AKQgOAkghAVQghAXgtAAQg8AAglgogArPgZICNAAQgDgbgQgRQgTgSgeAAQg+gBgLA/gAQqB4QgbgXAAglQAAgmAbgTQAWgPA0gLIAzgIQAWgFAAgQQAAgmgxAAQg1ABgEAtIg8gEQAEgnAfgXQAfgaAzAAQBsAAAABnIAACXIACAQIg1AAIAAgdIgBAAQgaAjg3ABQgvAAgagVgAR0AYQgnAGAAAeQAAAjAuAAQBEAAAAhDIAAgTgACxB4QgbgXAAglQAAgmAbgTQAXgPA0gLIAzgIQAWgFAAgQQAAgmg0AAQgwABgIAtIg6gEQADgnAggXQAfgaAwAAQBuAAABBnIAACnIg1AAIAAgMIACgRIgCAAQgZAjg4ABQguAAgbgVgAD8AYQgnAGAAAeQAAAjAtAAQBDAAAAhDIAAgGIADgNgAjkA6IA6gFQAPAqAtAAQAWAAAOgKQAPgJAAgPQAAgSgzgPIgdgGQhPgVAAg4QAAglAdgUQAdgYAvAAQArAAAdAVQAdATAEAmIg2ADQgKgggsAAQgpAAAAAdQAAASApANIAgAGQBTAWAAA2QAAAogdAXQggAXgwAAQhogBgOhSgAnlA6IA7gFQAKAqAyAAQAwAAAAgiQAAgSgwgPIgdgGQhRgWgBg3QAAglAggUQAdgYAuAAQArAAAeAVQAdATAEAmIg2ADQgNgggpAAQgsAAAAAdQAAASAsANIAdAGQAsAMAUAOQAWATAAAfQAAAoggAXQgdAXgyAAQhngBgOhSgA2/A6IA6gFQALAqAyAAQAwAAgBgiQABgSgwgPIgdgGQhRgWAAg3QAAglAdgUQAdgYAvAAQAsAAAeAVQAdATAEAmIg3ADQgMgggqAAQgsAAAAAdQAAASAsANIAdAGQBUAVAAA3QAAAogdAXQggAXgvAAQhngBgOhSgA7ZAeIAAieIA9AAIAACOQAABNA2gBQA7AAAAhRIAAiJIA8AAIAAEGIg5AAIAAglQgbArg2ABQhggBAAhugA/dBhIgDAAIADAlIg7AAIACllIA7AAIAACBQAbgqA6AAQA4AAAiAoQAhAmABA9QgBA9ghAnQgiAlg2ABQg8gBgdgrgA/Ig8QgVAWAAAnQAABaBLgBQAhABAVgZQATgZAAgmQAAgngTgYQgVgZghAAQgiAAgUAZgAfcCGIAAg+IA9AAIAAA+gAabCGQgsAAgRgMQgQgPAAglIAAiaIgoAAIAAgsIAoAAIAAhGIA8AAIAABGIAwAAIAAAsIgwAAIAAB9QAAAdAGAIQAGAIAWAAIASgBIgIAxgAW8CGIAAkGIA8AAIAAEGgAU7CGIAAllIA8AAIAAFlgAI3CGIAAkGIA5AAIAAAmQAQgsA7AAIASAAIAJA5QgNgDgVAAQgbAAgTAPQgSATAAA6IAAB6gAt6CGIAAiFQAAhWg2AAQglAAgMAcQgLAXAAAxIAAB3Ig8AAIAAkGIA4AAIAAAiQAfgqA0AAQAsAAAZAdQAZAbAAAzIAACjgAyqCGIAAkGIA8AAIAAEGgAW8ijIAAg8IA+AAIAAA8gAyqijIAAg8IA/AAIAAA8g");
	this.shape.setTransform(207.25,22.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,414.5,44.8), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApkDeIgIgwIAgAAQAYgBAPglIACgIIhkkBIBCAAIA/DAIACAAIA/jAIBCAAIhyEpIgCAGQgNAcgRAKQgQAKgoAAgAQ4BlQgjgmAAg+QAAg8AlgnQAmgoA6AAQBBAAAhAuQAfAoAABBIAAAFIjKAAQAEBGBFAAQAuAAAXglIA4AKQgOAkgiAVQghAXgsAAQg8AAgmgogARRgbICOAAQgGg/g/AAQg+AAgLA/gAlMBlQgmgmAAg+QAAg+AmglQAlgoA9AAQA+AAAmAoQAlAlAAA+QAAA+glAmQgmAog+AAQg/AAgjgogAkhg/QgUAZAAAnQAAAoAUAZQATAWAkAAQAjAAATgWQAVgZAAgoQAAgngVgZQgVgZghAAQgiAAgVAZgAv2BlQgkgmAAg+QAAg8AmgnQAlgoA7AAQBAAAAiAuQAfAoAABBIAAAFIjMAAQAGBGBFAAQAuAAAXglIA4AKQgPAkghAVQghAXgsAAQg9AAglgogAvdgbICOAAQgHg/g+AAQg/AAgKA/gAVcB2QgbgXAAgmQAAglAbgTQAVgQA0gKIAygJQAXgEAAgQQAAgmgyAAQg0AAgEAuIg7gEQAFgoAfgXQAdgZAyAAQBvAAAABmIAACoIg1AAIAAgdIgCAAQgZAkg4AAQguAAgZgVgAWlAWQgoAGAAAdQAAAkAuAAQBFAAAAhDIAAgTgAI5BlQghgoAAg8QAAg8AhgnQAigoA2AAQA8AAAcAqIAAh9IA6AAIACFhIg6AAIACglIgCAAQgeAsg8AAQg2AAgigmgAJpg9QgSAXAAAnQAAAlASAZQAVAZAfAAQAkAAAVgZQAVgZAAgmQAAgmgVgZQgVgZghAAQgiAAgVAbgAgvAcIAAidIA8AAIAACMQAABNA2AAQA6AAAAhRIAAiIIA7AAIACEFIg5AAIAAglIgCAAQgXAsg6AAQhdAAAAhvgA4fB2QgbgXAAgmQAAglAbgTQAXgQA0gKIAygJQAXgEAAgQQAAgmgyAAQgyAAgIAuIg6gEQAEgoAfgXQAfgZAyAAQBtAAAABmIAACYIACAQIg0AAIAAgdIgCAAQgZAkg5AAQguAAgbgVgA3UAWQgnAGAAAdQAAAkAuAAQBCAAAAhDIAAgGIACgNgAe9CEIAAiMQAAhQg0AAQg4AAAABNIAACPIg9AAIAAiMQAAhQg0AAQg4AAAABNIAACPIg7AAIgCkFIA7AAIAAAKIgDAXIADAAQAWgqA3AAQA4AAAXAsQAbgsA8AAQBgAAAABtIAAChgANoCEIAAkFIA4AAIAAAlQARgsA6AAIATAAIAIA5QgMgCgVAAQgbAAgTAOQgTATAAA5IAAB7gAD/CEIgDkFIA5AAIAAAlQAQgsA7AAIATAAIAIA5QgNgCgUAAQgcAAgSAOQgTATAAA5IAAB7gAxhCEIhdhwIgTAAIAABwIg9AAIAAlhIA9AAIAADAIARAAIBThkIBJAAIhsB2IBqB9IAAASgA6oCEIAAiMQAAhQgyAAQg7AAAABNIAACPIg6AAIAAiMQAAhQg0AAQg7AAAABNIAACPIg6AAIAAkFIA4AAIAAAhQAXgqA4AAQA3AAAXAsQAfgsA6AAQBeAAAABtIAAChg");
	this.shape.setTransform(204.125,22.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,408.3,44.4), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AMZEdIAAgEIA6AAIAAAEgA04EdIAAgEIA9AAIAAAEgAvqCeIA/gJQAQAkAuAAQBNAAAAhYIAAgMQgbArg+AAQg5AAgfgjQghgmAAg3QAAg6AhgkQAjglA1AAQA6AAAfAqIAAgiIA5AAIAADiQAAA/gkAjQgjAihBAAQhgAAgbhNgAuhg6QgVAXAAAjQAAAjATAXQAVAXAjAAQAfAAAXgXQAVgXAAglQAAgjgVgVQgUgXgiAAQghAAgVAXgAfHDlIAAlgIA5AAIAAAkQAfgsA6AAQA3AAAhAnQAjAmAAA+QAAA8ghAmQgjAng5AAQg2AAgfgqIACB+gEAgVgA4QgTAZAAAnQAAAnAVAXQASAZAiAAQAhAAAVgZQATgZAAglQAAgngTgZQgVgZghAAQgiAAgUAZgAE/CTIgdgSQgMgLAAgXIAFgUQAHgJANAAQALAAAHALQAHALAAAOIgDAUIgEAOIALAEIAOAAQAWAAAOgNQAQgOAAgZIgHgiQgJgUgOgUIgWgjQgMgNAAgeQAAgWAMgSQAJgQAWgLQASgJAbAAQAXAAALAEQASAFAJAJQALALAAAUIgEAOIgHANQgEAFgMAAQgLAAgHgHQgHgHAAgNQAAgOAFgHIALgRQgJgHgPAAQgVAAgNANQgMAQAAAUIADAXIAzBWQAKATAAAWQAAAUgMAXQgNAUgXAJQgQAMgfAAgACaCRQgLgHgCgLQgFgMAFgNIAEgdIBYkgQAHgUgHgHQgHgJgbAAIAFgLQAiAAAWgHIAygPIhzF+IgDAYQAFAHAHAAQALAAAJgJIAbg/IAJAAIgOAmQgGAZgLAJQgKALgNAHIgZAFQgUAAgHgHgAhqCDQgUgWAAgrQAAgiAFgSQAGgcAOgbQAPggATgSQAPgUAdgQQAagNAgAAQAkAAAUAUQAXAbAAAmIgHA0QgHAcgNAbQgQAggSASQgQAUgdAQQgaAOggAAQgkAAgUgVgAABhzQgMALgQAbQgLASgMAkQgNAogCAUIgHA9QAAAYAHAJQAGAJAOAAQAPAAAOgNQAOgMAPgbIAYgzIAQg/IAEg8QAAgXgGgLQgHgJgOAAQgPAAgOAOgAl6CDQgUgWAAgrIAGg0QAHgcAOgbIAfgyQASgUAbgQQAbgNAgAAQAkAAAWAUQAUAZAAAoIgHA0QgGAcgOAbIgfAyQgSAUgbAQQgbAOggAAQgiAAgYgVgAkOhzQgSASgJAUQgQAdgJAZIgQA8QgEAWAAAnQAAAYAGAJQAHAJAMAAQAPAAAQgNQASgSALgVIAXgzIAPg/QAHgdAAgfQAAgXgHgLQgGgJgOAAQgNAAgSAOgAouCOQgMgJgFgUQAAgZAFgPIA5jDIgwAAIADgMIAxAAIAXhRIA6gGIgYBXIBDAAIgDAMIhDAAIhCDcQgEARAHAHQAHAHALAAQAOAAAJgJQALgJALggIAJgWIAJAAIgLAiQgJAfgUAQQgVAOgbAAQgZAAgIgKgAYvBsQgkgmAAg+QAAg8AmgoQAlgnA7AAQBAAAAiAuQAfAnAABCIAAAEIjMAAQAGBHBFAAQAuAAAXglIA4AKQgPAjghAVQghAXgsAAQg9AAglgngAZIgVICOAAQgHg+g+AAQg/AAgKA+gANZBsQglgmAAg+QAAg+AlgmQAmgnA8AAQA/AAAlAnQAmAmAAA+QAAA+gmAmQglAng/AAQg+AAgkgngAOFg4QgVAZAAAnQAABXBLAAQBJAAAAhXQAAgngTgZQgUgZgiAAQghAAgVAZgA+rBsQgkgmAAg+QAAg8AmgoQAlgnA7AAQBAAAAiAuQAfAnAABCIAAAEIjKAAQAEBHBFAAQAuAAAXglIA4AKQgPAjghAVQghAXgsAAQg9AAglgngA+SgVICOAAQgHg+g+AAQg/AAgKA+gEgjTAA+IA4gEQAPApAuAAQAUAAAPgKQAPgIAAgPQAAgTgygOIgegHQhPgVAAg3QAAglAdgVQAdgXAuAAQBgAAANBNIg5AEQgKghgsAAQgpAAAAAdQAAATApAMIAgAHQBTAVAAA3QAAAngdAXQggAXgvAAQhnAAgOhTgAdGCLIAAlmIA9AAIAAFmgAWdCLIAAiIQAAhUg2AAQg9AAAABPIAACNIg8AAIAAlmIA8AAIgCB9QAdglA0AAQAsAAAbAbQAZAdAAAwIAACmgALzCLQgsAAgQgNQgRgOAAgmIAAiZIgoAAIAAgsIAoAAIAAhHIA8AAIAABHIAyAAIAAAsIgyAAIAAB8QAAAdAHAJQAGAIAVAAIASgCIgIAygAxjCLIAAiGQAAhWg0AAQgmAAgMAdQgLAXAAAxIAAB3Ig8AAIAAkGIA4AAIAAAiQAggqA0AAQArAAAaAdQAZAbAAAyIAACkgA2RCLIAAkGIA8AAIAAEGgA4TCLIAAlmIA9AAIAAFmgA6UCLIAAlmIA9AAIAAFmgA2RieIAAg9IA8AAIAAA9g");
	this.shape.setTransform(221.025,25.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-5,-2.6,452.1,57.1), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AIkEGQgPgCgQgLQgLgLAAgMQAAgGAHgMIARgRIAagOIAhgLIAFAIQgVAMgGALQgHALAAAOQAAAUAOAHQALAJAXAAQAVAAAPgFIAhgNIAZgWQAJgKAAgNQAAgJgHgFQgEgEgOAAIhRgXIgVgLQgJgJAAgOQAAgNAJgJQAKgLAWgQIA0gZIgJAAQgfAAgUgNQgVgOAAgeIAHgiQAGgSAOgSQALgSAbgLQAbgMAeAAQAWAAASAHQAHgJAJgHQASgNAUAAQAQAAAHAJQAJAGAAARQAAAPgIAJQgGAHgLAAQgKAAgGgHQgJgJAAgJQgCgLAHgQQgUAJgFAFIgFAJIADACQAUANAAAiQAAAbgQAZQgLAVgfASQgOAJgTAFIg8AgQgJAGAAAHQAAAHAGACIBgAgIAVAPQAKAOAAALQAAAOgLARQgMAVgRALQgOAMglANQgbAJgqAAQgiAAgOgFgAKlhoIgPAZQgIAJgEAWIgJA2QAAASAHAGQAGAHALAAQATAAALgLQANgOAIgOIAJgnIACgiIgFgbQgEgKgOAAQgJAAgSAIgAy2D7IAAlfIA5AAIAAAjQAbgsA+AAQA2AAAiAoQAhAmABA9QgBA9ghAlQgiAog4AAQg2AAgfgqIAAB9gAxrgiQgSAaAAAmQAAAoAVAXQAVAZAhAAQAhAAAVgZQATgZAAgmQAAgmgTgaQgVgZghAAQgjAAgWAZgAPjCmQgHgDgJgJIgFgbIA/jMQAFgLgFgHQAAgHgNAAQgJAAgQAMQgNALgQAXIggA0IgxCGIgJAhIg7AAIBGj2IgCgMQAAgEgJAAQgMAAgIALQgIAHgLAfIgIAXIgMAAIAOgmQANglAQgIQAWgMAQAAQASAAAHAHQAGAFAFANIAAAZIgYBkIAYg3IAkg4QAQgVAUgIQAQgKAUAAQAZAAALAMQAMAPAAAQIg9DDQgFALAAAOQAFAGAJAAQAJAAAJgIQALgJAJggIAHgWIALAAIgNAoQgIASgKAQQgTANgGADQgJAEgQAAQgSAAgEgEgAGjChQgKgLAAgSIAKgpIA4ifQAIgfgQAAQgNAAgGALQgMAQgJAWIgIAXIgKAAIANgmQAHgXANgOQAOgNALgCIAagFQARAAAKAHQAGAFAEANQADAOgDALIg/C8QgEALAAAOQAEAGAIAAQALAAAIgIIAeg/IAJAAIgNAmQgHAWgLALIgaATIgYAEQgZAAgIgJgADTCmQgPgFgOgOQgMgLAAgWIAFgVQAHgIAOAAQALAAAGALQAHALAAANIgDAVIgEANIALAFIAOAAQAXAAANgOQAQgNAAgZIgHgiIgthLQgMgOAAgdQAAgXAMgRQAJgRAWgKQASgKAbAAQAXAAALAFQATAFAIAIQALAMAAAUIgEAOQAAAEgJAJQgCAEgNAAQgKAAgHgHQgGgGgBgOQABgNAFgHIAKgSQgJgGgPAAQgVAAgNANQgMAQAAAUIADAWIAzBXQAKASAAAXQAAAUgMAXQgNAUgXAJQgQALgeAAgAgSChQgQgHgLgSQgJgWAAgVQAAgbAJgbQAQgpAJgQQASgeAVgWQAVgWAdgQQAggOAdAAQAUAAALAKQAOAKAAATQAAAUgOAUQgJAQgWASIgtAaIhIAdQgHAXAAAYQAAAbALAMQALANAQAAQAOAAAbgLQAegSANgXIAIAFIgdAiIgmAdQgUAJgbAAQgYAAgQgJgABZhjQgPAOgOARIgbAwIgQA1IAbgLQAbgMALgKQAXgUAKgSQAKgUAAggIgCgSQAAgEgHAAQgJAAgSANgAjICNIAAgVIANgvIAVg2IAGgyIAOg0QgCgMgHgHQgJgIgJAAQgSAAgSANQgMAJgWAeIgcAxIgRA6QgHAfAAAbQAAAXAHAJQAEALAMAAQANAAAOgOQAUgUALgUQAUggAMgdIAQguIgVBUIgUAiQgUAigUANQgTAQgdAAQgQAAgOgHQgPgLgEgNQgJgQAAgZQAAgdAJgbQAEgSASgoIAmg0QANgRAlgXQAbgOAgAAQANAAAJAKQAHAEAEAJIAZhhQAFgUgHgHQgHgJgbAAIAFgLQAfAAAbgHIAvgQIhpF+QgFAQACAHQAAAIAMAAQALAAAHgIIAUgpIAHgWIAJAAIgMAmQgGAWgMALQgLAOgNAFIgXAEQgkAAgCgdgArhCCQgjglAAg/QAAg7AlgoQAngoA5AAQBCAAAiAuIACADQAeAnAABAIAAAEIjMAAQAEBHBGAAQAwAAAUgmIA3ALQgIAUgPAQQgKALgOAJQgiAXgsAAQg8AAgmgogArHABICOAAQgHg+g/AAQg+AAgKA+gEghPABCIA8gHQAPA7BAAAQBFAAABg5QAAgUgRgNQgMgIgngLIgbgGQhngcAAhLQAAguAjgdQAkgdA5AAQBvAAAOBiIg8AEQgKgwg5AAQg8AAAAAuQAAAUATANQANAIAjALIAZAIQA4ATAVARQAbAVAAAsQAAAyglAgQgmAfg9AAQh2AAgThogAdkCCQghgnAAg9QAAg9AhgmQAigoA4AAQA6AAAcAqIAAiBIA8AAIAAFlIg4AAIAAglIgCAAQgZAshBAAQg2AAgigmgAeVgfQgUAXABAmQgBAmAUAZQAUAZAiAAQAjAAAVgZQATgZAAgoQAAgkgVgaQgVgZghAAQgiAAgUAcgAUVCTIgIgHIAAAKQgTgWAAggQAAggATgSIAAgKIAIgGQAWgRA1gKIAygHQAWgEAAgRQAAgmgxAAQg1AAgEAuIgxgDIAAAKIgLgBQACgUAJgQIAAgKQAJgPAPgMQAfgZAzAAQBsAAAABnIAACXIACAQIg0AAIAAgdIgCAAQgZAkg4AAQgvAAgagVgAVgAzQgoAGAAAdQAAAkAuAAQBEAAAAhDIAAgTgAbUChIAAiFQAAhXg2AAQglAAgMAeQgLAXAAAxIAAB2Ig9AAIAAkFIA7AAIgCAhIACAAQAbgqA2AAQAsAAAbAeQAZAbAAAyIAACjgAt0ChIAAllIA8AAIAAFlgA01ChIAAiNQAAhPgyAAQg6AAAABNIAACPIg9AAIAAiNQAAhPgxAAQg7AAAABNIAACPIg6AAIAAkFIA4AAIAAAhQAXgqA4AAQA3AAAWAsQAfgsA7AAQBeAAAABtIAAChgA8GChIAAkFIA9AAIAAEFgA8IiIIAAg8IA/AAIAAA8gAH0i5QgMgLAFgOQADgUAMgJQAQgLAOAAQANAAALALQAJAOgCALQgFASgKAJQgRALgNAAQgSAAgGgJg");
	this.shape.setTransform(205.8,23.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-7,-3,425.6,53.4), null);


(lib.mc_photo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.photo();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_photo, new cjs.Rectangle(0,0,600,500), null);


(lib.mc_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AikD6IAAnzIFEAAIAABNIjuAAIAACDIDdAAIAABKIjdAAIAACMIDzAAIAABNg");
	this.shape.setTransform(334.8,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AhYDxQgvgVgfghQgigkgRguQgRgvAAg5QAAg4ARguQARgwAigjQAhgiAtgVQAwgUA3AAQBSAAA4AnQA4AmAXBAIhZARQgTgngggWQgigWgtABQgkAAgdAOQgdAOgUAZQgVAZgKAiQgLAiAAAmQAAAmAMAjQALAiAUAZQAVAZAdANQAdAOAlAAQAyAAAfgYQAggYASghIBYAOQgMAegTAZQgUAagbATQgcATgjAMQgjALguAAQg3AAgugTg");
	this.shape_1.setTransform(283.8,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEFEFE").s().p("ACeD6IgziPIjaAAIgzCPIhSAAIAAgYIC0nbICEAAICxHbIAAAYgAhUAhIClAAIhHjOIgVAAg");
	this.shape_2.setTransform(229.8,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEFEFE").s().p("Ai4D6IAAnzIC4AAQA0AAAjAMQAkAMAVAVQAWAUAJAdQAKAcAAAhQAAAngOAcQgNAdgZASQgZAUgjAJQgiAJgsAAIhaAAIAADAgAhfgQIBUAAQAWAAAVgEQATgDAPgKQAOgIAIgQQAIgOAAgXQAAgXgIgQQgIgPgOgJQgOgIgUgFQgSgDgXAAIhWAAg");
	this.shape_3.setTransform(184.8,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEFEFE").s().p("Ah+DkQg0gkgLhLIBUgHQAIAmAcAVQAdAWAtAAQAsAAAZgWQAZgUgBgkQAAgRgGgLQgHgMgMgIQgLgIgSgGIhLgWQgggKgcgNQgdgOgQgPQgTgSgJgYQgKgWAAgfQAAggAMgaQAOgdAWgRQAXgUAggLQAjgLAmAAQBOAAAsAlQAtAmAIA+IhTAHQgHgfgYgSQgWgSgpAAQgmAAgWASQgVATAAAcQAAAPAHAMQAFAKANAIQANAKAPAFQAQAHAWAGIAjAMQAiALAbAMQAaALATAQQATAQAJAWQALAXAAAhQAAAjgOAeQgOAegZAUQgaAVghALQgiALgrAAQhMAAgzglg");
	this.shape_4.setTransform(134.3,-0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEFEFE").s().p("AikD6IAAnzIFEAAIAABNIjuAAIAACDIDdAAIAABKIjdAAIAACMIDzAAIAABNg");
	this.shape_5.setTransform(87.8,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEFEFE").s().p("ABqD6IiYjEIg5AAIAADEIhWAAIAAnzICiAAQAkAAAkAFQAjAGAcATQA7AmAABPQAAAigLAZQgJAZgRASQgTATgUAJQgUALgZAGICQC1IAAAYgAhngUIBMAAQAxgBAegRQAdgUAAgpQgBgqgdgQQgdgQgxAAIhMAAg");
	this.shape_6.setTransform(41.3,0);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FEFEFE").s().p("ACeD6IgziPIjaAAIgzCPIhSAAIAAgYICznbICFAAICxHbIAAAYgAhUAhIClAAIhHjOIgVAAg");
	this.shape_7.setTransform(-13.2,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FEFEFE").s().p("AhUD5QgkgLgagaQgZgYgPgoQgNgoAAg3IAAk4IBXAAIAAE2QAABFAeAhQAdAjA1AAQA1AAAegjQAdghAAhFIAAk2IBYAAIAAE4QAAA2gOApQgOAogaAYQgZAagmALQgkALgvAAQgvAAglgLg");
	this.shape_8.setTransform(-66.7,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FEFEFE").s().p("ACeEYIgug6QgZAMgbAGQgbAGghABQg5AAgugUQgvgTgfgjQgggigTgyQgRguAAg6QAAg7ARgvQATgxAggiQAggkAvgTQAvgUA3AAQA4AAAuATQAuAUAhAjQAgAhASAzQATAxAAA5QAAA7gTAxQgUAwgjAjIBDBQIAAAYgAhDi9QgeAOgVAaQgTAXgMAjQgLAjAAAoQAAAoAMAiQALAiAUAZQATAZAfAPQAcAOAnAAQAlAAAdgNQAdgNAVgZQAVgbALghQALgjAAgoQAAgogLgkQgLghgVgaQgVgYgdgPQgdgOgmABQgmgBgcAOg");
	this.shape_9.setTransform(-125.7,2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FEFEFE").s().p("Ah+DkQg0gkgLhLIBUgHQAIAmAcAVQAdAWAtAAQAsAAAZgWQAZgUgBgkQAAgRgGgLQgHgMgMgIQgKgIgTgGIhLgWQgggKgcgNQgcgNgRgQQgTgTgJgXQgKgWAAgfQAAggAMgaQAOgdAWgRQAXgUAggLQAjgLAmAAQBOAAAsAlQAtAmAJA+IhUAHQgHgfgYgSQgWgSgpAAQgmAAgWASQgVATAAAcQAAAPAHAMQAFAKANAIQANAKAPAFQAQAHAWAGIAjAMQAiALAbAMQAaALATAQQATAQAJAWQALAXAAAhQAAAjgOAeQgOAegZAUQgaAVghALQgiALgrAAQhMAAgzglg");
	this.shape_10.setTransform(-180.7,-0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FEFEFE").s().p("AkND4QgqgSggghIgfgfIA9g+IAfAfQApAqA8AAQA7AAApgqIGKmPIA+A/ImKGOQggAhgqASQgrARgtAAQguAAgqgRg");
	this.shape_11.setTransform(-285.2,23.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FEFEFE").s().p("AhME0IFWlXQAqgqAAg8QAAg7gqgrQgqgqg7AAQg8AAgpAqImMGOIg+g9IGMmPQAgghArgRQAqgRAugBQAuAAAqASQAqARAhAhQBDBEAABgQAABghDBDIlWFYg");
	this.shape_12.setTransform(-267.225,14);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FEFEFE").s().p("Aj8FhQgrgSggghQhDhEAAhgQAAhfBDhDIFWlZIA9A+IlVFYQgqAqAAA7QAAA8AqAqQAqAqA7ABQA8AAApgrIGMmOIA+A+ImMGOQggAhgrASQgqARguAAQguAAgqgRg");
	this.shape_13.setTransform(-313.2,-14);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FEFEFE").s().p("Al2DLIGJmPQAhghAqgRQAqgRAugBQAuAAAqASQApARAhAhIAfAgIg+A+IgfggQgqgqg6AAQg8AAgpAqImKGPg");
	this.shape_14.setTransform(-295.2,-23.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_logo, new cjs.Rectangle(-352.7,-51,704,102), null);


(lib.mc_cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {off:0,on:1};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AKQAPIALgBQACALAMgBQAMAAAAgKQAAgDgDgCIgJgEIgEgCQgTgDAAgOQAAgJAGgEQAHgGAKAAQAUAAADASIgLAAQgDgIgJAAQgLAAAAAIQAAAGAMAEIAFABQAJAEAEACQAGAEAAAHQAAAKgIAFQgGAGgLgBQgWAAgDgSgAJYAPIALgBQADALAMgBQAMAAAAgKQAAgDgDgCIgJgEIgFgCQgSgDgBgOQAAgJAHgEQAGgGALAAQAUAAACASIgLAAQgCgIgJAAQgLAAAAAIQAAAGALAEIAFABQAKAEAEACQAFAEAAAHQAAAKgHAFQgGAGgLgBQgWAAgEgSgAGMAPIAMgBQABALAMgBQANAAAAgKQAAgDgDgCIgJgEIgFgCQgSgDAAgOQgBgJAHgEQAGgGAKAAQAVAAACASIgKAAQgDgIgKAAQgLAAAAAIQAAAGAMAEIAFABQAKAEADACQAGAEAAAHQgBAKgGAFQgHAGgLgBQgVAAgEgSgAFPAIIAAgoIALAAIAAAnQAAARAPAAQAOAAAAgRIAAgnIAMAAIAAAoQAAAZgaAAQgaAAAAgZgAjbAIIAAgoIAKAAIAAAnQABARAPAAQAOAAAAgRIAAgnIAMAAIAAAoQAAAZgaAAQgaAAAAgZgAkeAYQgJgJAAgPQAAgOAJgJQAJgKAOAAQAPAAAJAKQAJAJAAAOQAAAPgIAJQgKAKgPgBQgOABgJgKgAkWgQQgGAGABAKQgBALAGAGQAGAHAJAAQAKAAAGgGQAFgIAAgKQAAgKgFgGQgGgHgKAAQgJAAgGAHgAnyAYQgJgJAAgPQAAgOAJgJQAJgKAPAAQAWABAHARIgLACQgGgKgMAAQgKAAgFAHQgGAGAAAKQAAALAGAHQAFAGAKAAQARAAADgQIgaAAIAAgJIAiAAIADADQAAAPgJAJQgJAHgNAAQgOAAgKgJgApNAPIALgBQACALAMgBQAMAAABgKQgBgDgDgCIgIgEIgGgCQgSgDAAgOQAAgJAGgEQAHgGAKAAQAUAAACASIgKAAQgCgIgKAAQgLAAAAAIQAAAGAMAEIAEABQALAEADACQAFAEAAAHQAAAKgHAFQgHAGgKgBQgWAAgDgSgAInAgIAAhAIAqAAIAAAKIgfAAIAAARIAcAAIAAAJIgcAAIAAASIAfAAIAAAKgAIKAgIgdgxIAAAAIAAAxIgLAAIAAhAIAPAAIAdAyIAAgyIAKAAIAABAgAHIAgIAAhAIAMAAIAABAgAEUAgIAAhAIAZAAQAUABAAAQQABAKgKAFQAMACAAAMQAAASgXAAgAEfAXIANAAQANAAAAgKQAAgJgNAAIgNAAgAEfgFIAMAAQALABAAgKQAAgIgLAAIgMAAgADlAgIABg2IgBAAIgSA2IgLAAIgSg2IAAA2IgMAAIAAhAIASAAIARAzIASgzIARAAIAABAgACWAgIgGgSIgcAAIgGASIgLAAIAAgDIAXg9IARAAIAWA9IAAADgACNAEIgKgaIgCAAIgJAaIAVAAgAAyAgIAAhAIArAAIAAAKIgfAAIAAARIAcAAIAAAJIgcAAIAAASIAfAAIAAAKgAAeAgIgUgZIgHAAIAAAZIgLAAIAAhAIAVAAQAMAAAFAFQAIAFAAAJQgBAPgPAEIATAXIAAADgAADgCIAKAAQANABAAgLQAAgKgNAAIgKAAgAhKAgIAAhAIAVAAQAOABAKAGQALAIgBARQAAAOgIAJQgJAJgRAAgAg+AWIAJAAQAXABAAgXQAAgLgHgFQgFgFgOgBIgGAAgAh0AgIgTgZIgIAAIAAAZIgLAAIAAhAIAWAAQALAAAGAFQAIAFgBAJQAAAPgPAEIATAXIAAADgAiPgCIALAAQAOABgBgLQABgKgOAAIgLAAgAlKAgIAAgXIgVgkIAAgFIALAAIAHAOIAJARIAQgfIAKAAIAAAFIgUAkIAAAXgAmIAgIgdgxIgBAAIABAxIgLAAIAAhAIAOAAIAcAyIABAAIgBgyIALAAIAABAgAoRAgIAAhAIALAAIAABAgAp/AgIAAhAIAqAAIAAAKIgfAAIAAARIAdAAIAAAJIgdAAIAAASIAgAAIAAAKgArBAgIAAhAIAVAAQAOABAKAGQAKAIAAARQAAAOgJAJQgJAJgQAAgAq2AWIAKAAQAWABAAgXQAAgLgGgFQgGgFgNgBIgHAAg");
	this.shape.setTransform(3.0989,0.6999,2,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AQhEsMgrsAAAIAApXMA2XAAAIAAJXg");
	this.shape_1.setTransform(0,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.8)").s().p("AQhEsMgrsAAAIAApXMA2XAAAIAAJXg");
	this.shape_2.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174,-30,348,60.1);


(lib.mc_back = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Egu3AnEMAAAhOHMBdvAAAMAAABOHg");
	this.shape.setTransform(300,250);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_back, new cjs.Rectangle(0,0,600,500), null);


(lib.clickthrough = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.mc_copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.c4 = new lib.Symbol4();
	this.c4.name = "c4";
	this.c4.setTransform(83,310,1,1,0,0,0,-11,10);

	this.c3 = new lib.Symbol3();
	this.c3.name = "c3";
	this.c3.setTransform(82,262,1,1,0,0,0,-16,12);

	this.c2 = new lib.Symbol2();
	this.c2.name = "c2";
	this.c2.setTransform(77,212,1,1,0,0,0,-3,16);

	this.c1 = new lib.Symbol1();
	this.c1.name = "c1";
	this.c1.setTransform(80,161,1,1,0,0,0,-14,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.c1},{t:this.c2},{t:this.c3},{t:this.c4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_copy, new cjs.Rectangle(75,143,452.1,201.8), null);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		/**
		* Squarewave CreateJS Template 3.3 (Feb '21)
		**/
		var root = r = this,
		    adCompleted = false,
			isOver = false,
			timeout,
			tl;
		
		var EO = Elastic.easeOut.config;
		var EI = Elastic.easeIn.config;
		var EIO = Elastic.easeInOut.config;
		var R = gsap.utils.Random;
		
		/**** uncomment to use within creative ******/
		/*
		root.clickthrough.on('mouseover' , onRollOver );
		root.clickthrough.on('mouseout' , onRollOut );
		root.clickthrough.on('click' , onClick );
		*/
		
		/*
		* remove elements for backup capture
		*/
		if( queryVar('capture') ) {
			// use this for removing items in backups
		}
		
		this.onInit = function()
		{
			setTimeout( function(){ 
				console.log('%c----------------------------------------\n------------- 15 SECONDS ---------------\n----------------------------------------\n', 'background: #ffff33; color: #ff00ff');
			} , 15000 );
				
			r.tl = tl = gsap.timeline({onComplete:function(){ if(!isOver){ r.adHelper.sleep(); } adCompleted = true; }});
			tl.add( "start" , "+=0" );
			tl.add( function(){ console.log('end'); } , "start+=14.5" );
			
			tl.addLabel("frame01", "start+=.25");
			tl.from(root.m_copy.c1, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01");
			tl.from(root.m_copy.c2, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.2");
			tl.from(root.m_copy.c3, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.4");
			tl.from(root.m_copy.c4, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.6");
			//tl.from(root.m_copy.c5, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=.8");
			//tl.from(root.m_copy.c6, .8, {alpha:0, scaleY:"-=.3", rotation:-5, ease:Quad.easeInOut}, "frame01+=1");
			
			//tl.from(root.m_subTxt, .8, {alpha:0}, "frame01+=1");
		}
		
		this.onRollOverEvent = function(e)
		{
			// wake up creative if asleep //
			clearTimeout( timeout );
			if( root.adHelper && !root.adHelper.awake ) root.adHelper.wake();
			isOver = true;
			console.log("creative-mouse over" );
			if( adCompleted ) {}
			
			root.m_cta.gotoAndStop("on");
		}
		
		this.onRollOutEvent = function(e)
		{
			if( adCompleted ) timeout = setTimeout( function(){ if(!isOver) r.adHelper.sleep(); } , 3000 );
			isOver = false
			console.log("creative-mouse out" );
			if( adCompleted ) {}
			
			root.m_cta.gotoAndStop("off");
		}
		
		this.onClickEvent = function(e)
		{
			console.log("creative-click");
		}
		
		this.adHelper = null; // adhelper reference //
		this.onSlowDown = function()
		{
			console.log("creative-slowdown");
		}
		
		this.onSleep = function()
		{
			console.log("creative-sleep");
		}
		
		this.onWake = function()
		{
			console.log("creative-wake");
		}
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// pixel
	this.instance = new lib.dot();
	this.instance.setTransform(-10,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// clickthrough
	this.clickthrough = new lib.clickthrough();
	this.clickthrough.name = "clickthrough";
	this.clickthrough.setTransform(300,250,2,2,0,0,0,150,125);
	new cjs.ButtonHelper(this.clickthrough, 0, 1, 2, false, new lib.clickthrough(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickthrough).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Egu3AnEMAAAhOHMBdvAAAMAAABOHgEgujAmwMBdHAAAMAAAhNfMhdHAAAg");
	this.shape.setTransform(300,250);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// cta
	this.m_cta = new lib.mc_cta();
	this.m_cta.name = "m_cta";
	this.m_cta.setTransform(300.1,428,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.m_cta).wait(1));

	// logo
	this.instance_1 = new lib.mc_logo();
	this.instance_1.setTransform(300.15,78.2,0.5,0.5,0,0,0,0.3,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// copy
	this.m_copy = new lib.mc_copy();
	this.m_copy.name = "m_copy";

	this.timeline.addTween(cjs.Tween.get(this.m_copy).wait(1));

	// photo
	this.instance_2 = new lib.mc_photo();
	this.instance_2.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// back
	this.instance_3 = new lib.mc_back();
	this.instance_3.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(290,240,310,260);
// library properties:
lib.properties = {
	id: '297D501141974662AAF7687B5444E494',
	width: 600,
	height: 500,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/photo.jpg?1652974835621", id:"photo"},
		{src:"images/dot.png?1652974835621", id:"dot"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['297D501141974662AAF7687B5444E494'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;